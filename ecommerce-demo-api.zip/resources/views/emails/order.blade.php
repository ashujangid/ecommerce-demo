<h2>Thanks for your order!</h2>
<p>Order ID: {{ $order->order_id }}</p>
<p>Status: {{ ucfirst($order->status) }}</p>
