<h2>Thanks for your order!</h2>
<p>Order ID: <?php echo e($order->order_id); ?></p>
<p>Status: <?php echo e(ucfirst($order->status)); ?></p>
<?php /**PATH D:\xampp8.2\htdocs\ecommerce-demo-api\resources\views/emails/order.blade.php ENDPATH**/ ?>